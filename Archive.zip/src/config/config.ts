export default (): any => ({
  databaseMongodb: process.env.MONGOBD || '',
});
